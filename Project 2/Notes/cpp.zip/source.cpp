#include <stdio.h>
#include <stdlib.h>

#include "Grid.h"

#include "LinkList.h"
#include "Stack.h"
#include "Queue.h"


/* ------------- QUEUE FUNCTIONS ------------------ */
Queue::Queue(){

}
Queue::~Queue(){
    if(l != NULL)
        delete l;
}

void Queue::enqueue(int x, int y){

}

void Queue::dequeue(int &x, int &y){

}

int Queue::size(){

}

/* ------------- STACK FUNCTIONS ------------------ */
Stack::Stack(){

}

Stack::~Stack(){
    if(l != NULL)
        delete l;
}

void Stack::push(int x, int y){

}

void Stack::pop(int &x, int &y){

}

int Stack::size(){

}

/* ------------- SEARCH FUNCTIONS ------------------ */
Search* FindPath(Grid* g){

}

Grid* ReadWorld(const char* filename){

}

