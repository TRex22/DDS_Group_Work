#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "postfix.h"
/*********************************************************/
// Allocate the stack and setup size and capacity
CharStack* stack_c_init(){

}

// Push to the top of stack
void stack_c_push(CharStack* s, char c){

}

// Pop off the top of stack
char stack_c_pop(CharStack* s){

}

// Return the top of the stack without removing it
char stack_c_peek(CharStack* s){

}

/*********************************************************/
// Allocate the stack and setup size and capacity
IntStack* stack_i_init(){

}

// Push to the top of stack
void stack_i_push(IntStack* s, int c){

}

// Pop from the top of stack
int  stack_i_pop(IntStack* s){

}

// Return the top of the stack without removing it
int  stack_i_peek(IntStack* s){

}

/*********************************************************/
int calculate(char* p){
}

char* convert(char* in){

}


int calculate_extra(char* in){

}

